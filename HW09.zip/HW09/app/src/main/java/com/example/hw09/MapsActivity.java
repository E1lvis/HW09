//HW09
//HW09
//Elvis Velasquez, Eduardo Gomez
package com.example.hw09;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.hw09.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.HttpUrl;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private final OkHttpClient client = new OkHttpClient();
    PolylineOptions polylineOptions = new PolylineOptions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());





        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);



    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        HttpUrl url = HttpUrl.parse("https://www.theappsdr.com/map/route").newBuilder()
                //.addQueryParameter("lat", String.valueOf(mCity.getLat()))
                .build();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                ResponseBody re = response.body();
                String s = re.string();
                try {
                    JSONObject Json = new JSONObject(s);
                    Log.d("TAG", "onResponse: Success");

                    //Log.d("TAG", "onResponse: " + Json.getString("title"));
                    JSONArray temp = Json.getJSONArray("path");
                    //Log.d("TAG", "onResponse: " + temp.getJSONObject(1));


                    for (int i = 0; i < temp.length(); i++) {
                        JSONObject tempObject = temp.getJSONObject(i);
                        //Log.d("TAG", "onResponse: " + tempObject.getString("latitude"));
                        //Log.d("TAG", "onResponse: " + tempObject.getString("longitude"));
                        polylineOptions.add(new LatLng(Double.parseDouble(tempObject.getString("latitude")), Double.parseDouble(tempObject.getString("longitude"))));
                    }

                    Handler han = new Handler(Looper.getMainLooper());
                    Runnable run = new Runnable() {
                        @Override
                        public void run() {
                            Polyline polyline = mMap.addPolyline(polylineOptions);

                            try {
                                JSONObject tempObject1 = temp.getJSONObject(0);
                                JSONObject tempObject2 = temp.getJSONObject(temp.length()-1);
                                mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(tempObject1.getString("latitude")), Double.parseDouble(tempObject1.getString("longitude")))).title("Start"));
                                mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(tempObject2.getString("latitude")), Double.parseDouble(tempObject2.getString("longitude")))).title("End"));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };

                    han.post(run);


                }catch (JSONException e) {
                    Log.d("TAG", "onResponse: FAILED " + e.getMessage() );
                    e.printStackTrace();
                }

            }




        });





        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);

        //mMap.addMarker(new MarkerOptions().position(new LatLng(35.354335, -80.74401833333333)).title("Marker in Sydney"));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(35.3000, -80.8200), 10));


    }

}